CREATE DATABASE IF NOT EXISTS student_db;
USE student_db;

CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  course VARCHAR(100) NOT NULL,
  year INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample records for testing (optional).
INSERT IGNORE INTO students (name, email, course, year) VALUES
('Ananya Rao', 'ananya@example.com', 'Computer Science', 2),
('Rahul Kumar', 'rahul@example.com', 'Information Technology', 3);