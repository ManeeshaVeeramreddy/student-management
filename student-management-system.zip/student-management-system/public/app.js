const API = "/api/students";
const form = document.getElementById("studentForm");
const rows = document.getElementById("studentRows");
const message = document.getElementById("message");
const submitBtn = document.getElementById("submitBtn");
const cancelBtn = document.getElementById("cancelBtn");
let editingId = null;
let searchTimer;

function showMessage(text, isError=false) {
  message.textContent = text;
  message.style.color = isError ? "#d04e48" : "#23845c";
  setTimeout(() => { if (message.textContent === text) message.textContent = ""; }, 3500);
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[ch]));
}
async function loadStudents(search="") {
  try {
    const response = await fetch(`${API}?search=${encodeURIComponent(search)}`);
    if (!response.ok) throw new Error("Request failed");
    const students = await response.json();
    document.getElementById("totalCount").textContent = students.length;
    document.getElementById("courseCount").textContent = new Set(students.map(s=>s.course)).size;
    document.getElementById("yearCount").textContent = new Set(students.map(s=>s.year)).size;
    rows.innerHTML = students.length ? students.map(s => `
      <tr>
        <td class="student-id">#${s.id}</td>
        <td><strong>${escapeHTML(s.name)}</strong></td>
        <td>${escapeHTML(s.email)}</td><td>${escapeHTML(s.course)}</td>
        <td>Year ${s.year}</td>
        <td><button class="action" data-edit="${s.id}">Edit</button><button class="action delete" data-delete="${s.id}">Delete</button></td>
      </tr>`).join("") : '<tr><td colspan="6" class="empty">No student records found. Add your first student above.</td></tr>';
    window.currentStudents = students;
  } catch (error) {
    rows.innerHTML = '<tr><td colspan="6" class="empty">Could not load records. Check that the server and database are running.</td></tr>';
  }
}
function resetForm() {
  editingId = null; form.reset();
  document.getElementById("formTitle").textContent = "Add a student";
  submitBtn.textContent = "+ Add student";
  cancelBtn.classList.add("hidden");
}
form.addEventListener("submit", async event => {
  event.preventDefault();
  const data = {
    name: document.getElementById("name").value.trim(),
    email: document.getElementById("email").value.trim(),
    course: document.getElementById("course").value.trim(),
    year: Number(document.getElementById("year").value)
  };
  try {
    const response = await fetch(editingId ? `${API}/${editingId}` : API, {
      method: editingId ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || "Something went wrong.");
    showMessage(editingId ? "Student updated successfully." : "Student added successfully.");
    resetForm(); loadStudents(document.getElementById("search").value);
  } catch (error) { showMessage(error.message, true); }
});
cancelBtn.addEventListener("click", resetForm);
rows.addEventListener("click", async event => {
  const editId = event.target.dataset.edit;
  const deleteId = event.target.dataset.delete;
  if (editId) {
    const student = (window.currentStudents || []).find(s => s.id === Number(editId));
    if (!student) return;
    editingId = student.id;
    document.getElementById("name").value = student.name;
    document.getElementById("email").value = student.email;
    document.getElementById("course").value = student.course;
    document.getElementById("year").value = student.year;
    document.getElementById("formTitle").textContent = "Update student";
    submitBtn.textContent = "Save changes";
    cancelBtn.classList.remove("hidden");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  if (deleteId && confirm("Are you sure you want to delete this student?")) {
    try {
      const response = await fetch(`${API}/${deleteId}`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message);
      showMessage("Student deleted successfully.");
      loadStudents(document.getElementById("search").value);
    } catch (error) { showMessage(error.message, true); }
  }
});
document.getElementById("search").addEventListener("input", event => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => loadStudents(event.target.value), 250);
});
loadStudents();