require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2/promise");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "root123",
  database: process.env.DB_NAME || "student_db",
  waitForConnections: true,
  connectionLimit: 10
});

// Create the table automatically when the server starts.
async function initializeDatabase() {
  let attempts = 0;
  while (attempts < 20) {
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS students (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(100) NOT NULL,
          email VARCHAR(150) NOT NULL UNIQUE,
          course VARCHAR(100) NOT NULL,
          year INT NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
      console.log("Database connected and table is ready.");
      return;
    } catch (error) {
      attempts++;
      console.log(`Waiting for MySQL... (${attempts}/20)`);
      await new Promise(resolve => setTimeout(resolve, 3000));
    }
  }
  throw new Error("Could not connect to MySQL. Check database settings.");
}

// READ: get all students, optionally search by name/email/course.
app.get("/api/students", async (req, res) => {
  try {
    const search = `%${req.query.search || ""}%`;
    const [rows] = await pool.execute(
      "SELECT * FROM students WHERE name LIKE ? OR email LIKE ? OR course LIKE ? ORDER BY id DESC",
      [search, search, search]
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: "Could not fetch students." });
  }
});

// CREATE: add a student.
app.post("/api/students", async (req, res) => {
  const { name, email, course, year } = req.body;
  if (!name || !email || !course || !Number.isInteger(Number(year)) || Number(year) < 1 || Number(year) > 6) {
    return res.status(400).json({ message: "Enter valid name, email, course and year (1-6)." });
  }
  try {
    const [result] = await pool.execute(
      "INSERT INTO students (name, email, course, year) VALUES (?, ?, ?, ?)",
      [name.trim(), email.trim(), course.trim(), Number(year)]
    );
    const [rows] = await pool.execute("SELECT * FROM students WHERE id = ?", [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (error) {
    res.status(error.code === "ER_DUP_ENTRY" ? 409 : 500).json({
      message: error.code === "ER_DUP_ENTRY" ? "This email is already registered." : "Could not add student."
    });
  }
});

// UPDATE: edit a student's details.
app.put("/api/students/:id", async (req, res) => {
  const { name, email, course, year } = req.body;
  if (!name || !email || !course || !Number.isInteger(Number(year)) || Number(year) < 1 || Number(year) > 6) {
    return res.status(400).json({ message: "Enter valid student details." });
  }
  try {
    const [result] = await pool.execute(
      "UPDATE students SET name=?, email=?, course=?, year=? WHERE id=?",
      [name.trim(), email.trim(), course.trim(), Number(year), req.params.id]
    );
    if (!result.affectedRows) return res.status(404).json({ message: "Student not found." });
    const [rows] = await pool.execute("SELECT * FROM students WHERE id=?", [req.params.id]);
    res.json(rows[0]);
  } catch (error) {
    res.status(error.code === "ER_DUP_ENTRY" ? 409 : 500).json({
      message: error.code === "ER_DUP_ENTRY" ? "This email is already registered." : "Could not update student."
    });
  }
});

// DELETE: remove a student.
app.delete("/api/students/:id", async (req, res) => {
  try {
    const [result] = await pool.execute("DELETE FROM students WHERE id=?", [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ message: "Student not found." });
    res.json({ message: "Student deleted successfully." });
  } catch (error) {
    res.status(500).json({ message: "Could not delete student." });
  }
});

const PORT = process.env.PORT || 3000;
initializeDatabase()
  .then(() => app.listen(PORT, () => console.log(`App running at http://localhost:${PORT}`)))
  .catch(error => { console.error(error); process.exit(1); });