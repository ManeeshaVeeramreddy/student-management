# Student Management System

A beginner-friendly full-stack lab project using HTML, CSS, JavaScript, Node.js, Express, MySQL and Docker.

## 1. Requirements
- Docker Desktop (recommended for the exam)
- A web browser

For running without Docker, install Node.js 20+ and MySQL 8+.

## 2. Run the complete application with Docker

Open PowerShell in this project folder and run:

```powershell
docker compose up --build
```

Wait until the app says the database is connected and the server is running. Open:

http://localhost:3000

The MySQL database is available on localhost port 3307 from your computer. Inside Docker, the app connects to the database service named `db` on port 3306.

To stop the application, press `Ctrl + C`, then run:

```powershell
docker compose down
```

To stop and delete the database volume (this permanently deletes saved student records):

```powershell
docker compose down -v
```

## 3. Run without Docker (optional)

1. Install Node.js and MySQL.
2. Create the database by running `database/schema.sql` in MySQL.
3. Copy `.env.example` to `.env` and set your local MySQL password.
4. In this folder, run:

```powershell
npm install
npm start
```

Open http://localhost:3000.

## 4. API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/students` | View all students |
| GET | `/api/students?search=an` | Search students |
| POST | `/api/students` | Add a student |
| PUT | `/api/students/:id` | Update a student |
| DELETE | `/api/students/:id` | Delete a student |

Example POST JSON:

```json
{
  "name": "Poojitha",
  "email": "poojitha@example.com",
  "course": "Computer Science",
  "year": 4
}
```

## 5. SQL operations covered

- `CREATE DATABASE` and `CREATE TABLE`
- `INSERT` to add records
- `SELECT` to display and search records
- `UPDATE` to modify records
- `DELETE` to remove records
- Primary key, auto increment, unique email and parameterized queries

## 6. Project folder structure

```text
student-management-system/
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── database/
│   └── schema.sql
├── server.js
├── package.json
├── Dockerfile
├── docker-compose.yml
├── .dockerignore
├── .env.example
└── README.md
```

## 7. Important exam explanation

1. The user enters student details in the frontend form.
2. JavaScript sends an HTTP request to the Express backend.
3. The backend validates the input and executes a parameterized SQL query.
4. MySQL stores or returns the student record.
5. The backend sends JSON to the frontend.
6. JavaScript updates the table without reloading the page.
7. Docker Compose runs the application container and MySQL container together.

**Note:** This is a learning/demo application. The default database password is only for local practice; change it before any public deployment.